# A Deep Dive into NLP with PyTorch

Talk: https://pydata.org/london2019/schedule/presentation/17/

Report: https://github.com/scoutbee/pytorch-nlp-notebooks