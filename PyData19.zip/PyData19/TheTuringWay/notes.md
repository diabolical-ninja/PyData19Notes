# The Turing Way

https://github.com/alan-turing-institute/the-turing-way#contributors
https://the-turing-way.netlify.com/introduction/introduction.html
https://zenodo.org/record/3333760



FAIR
- Findable
- Accessible
- Interoperable
- Reproducible



Indicate how things are going by using difference colour postit notes your laptop
- Yellow = all good
- Red = could use a hand    
- (could add a do no disturb note?)



Binder
* https://mybinder.readthedocs.io/en/latest/
* https://github.com/jupyterhub/binderhub

Allows code to run from any browser. Can perform code reviews from a phone!! 


The book is being extended to ethics, model selections, collaboration etc
