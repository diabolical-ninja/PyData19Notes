# An Introduction to Markov chain Monte Carlo using PyMC3

Talk: https://pydata.org/london2019/schedule/presentation/11/

