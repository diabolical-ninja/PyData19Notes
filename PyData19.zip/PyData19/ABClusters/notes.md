# AB-testing by clusters

Talk: https://pydata.org/london2019/schedule/presentation/24/

Code: https://github.com/bertilhatt/pydata_pres_small_sample

